# Listing_15-3.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Putting your program to sleep

import time

print "How",
time.sleep(2)
print "are", 
time.sleep(2)
print "you",
time.sleep(2)
print "today?"
