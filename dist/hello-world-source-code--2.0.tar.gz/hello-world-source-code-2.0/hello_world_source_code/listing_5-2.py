# Listing_5-2.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# What does the comma do?

print "My",
print "name",
print "is",
print "Dave."
