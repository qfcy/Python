# Listing_13-2
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Passing an argument to a function

# define a function with an argument
def printMyAddress(myName):                               
    print myName                   # we passed myName to the function                
    print "123 Main Street"           
    print "Ottawa, Ontario, Canada"          
    print "K2M 2E9"                   
    print                             
    
#call the function and pass an argument to it
printMyAddress("Carter Sande")                   
